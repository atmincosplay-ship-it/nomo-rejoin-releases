# NOMO Rejoin V4.04 — GitHub Releases migration

This replaces the abandoned Cloudflare R2 updater. The clients read the latest **published GitHub Release** from a public release-only repository. No GitHub token is stored on normal Redfingers.

## What to upload to GitHub

Inside this setup package, open:

```text
UPLOAD_THESE_TO_GITHUB/
```

Upload both files to the V4.04 GitHub Release:

```text
NOMO_REJOIN_V4.04.zip
NOMO_REJOIN_V4.04.sha256
```

Do **not** upload the full setup ZIP as the release asset. The updater expects the clean `NOMO_REJOIN_V*.zip` plus its checksum file.

---

## Part 1 — Create the repository

1. Sign in to GitHub.
2. Create a new repository.
3. Name it:

```text
nomo-rejoin-releases
```

4. Set visibility to **Public**.
5. Enable **Add a README file**. A non-empty repository gives the first release tag a branch to target.
6. Create the repository.

The repository is release-only. Do not upload any of these:

```text
nomo.json
runtime.json
cookie_cache.json
cookies or cookie exports
private-server credentials
GitHub tokens
Cloudflare secrets
activity.log
```

You may replace the repository README with the included `REPOSITORY_README.md`.

---

## Part 2 — Publish V4.04 in the browser (easiest; no token)

1. Open the new repository.
2. Open **Releases**.
3. Choose **Draft a new release**.
4. Create/select this tag:

```text
V4.04
```

5. Release title:

```text
NOMO Rejoin V4.04
```

6. Upload these two files from `UPLOAD_THESE_TO_GITHUB/`:

```text
NOMO_REJOIN_V4.04.zip
NOMO_REJOIN_V4.04.sha256
```

7. Confirm it is a normal release, not a prerelease.
8. Publish the release.

The updater reads only published, non-prerelease releases. A draft will not appear as `latest`.

---

## Part 3 — Extract this setup kit in Termux

Assuming the downloaded file is in `/sdcard/Download`:

```bash
rm -rf /sdcard/Download/NOMO_GITHUB_SETUP && mkdir -p /sdcard/Download/NOMO_GITHUB_SETUP && unzip -o /sdcard/Download/NOMO_REJOIN_V4.04_GITHUB_SETUP.zip -d /sdcard/Download/NOMO_GITHUB_SETUP
```

---

## Part 4 — Install on a Redfinger

Replace `YOUR_GITHUB_NAME` with the owner shown in the repository URL:

```bash
bash /sdcard/Download/NOMO_GITHUB_SETUP/install_client_only.sh 'YOUR_GITHUB_NAME/nomo-rejoin-releases'
```

The installer:

- migrates the old `gag_lite_rejoiner` folder when needed;
- installs V4.04 locally at `/storage/emulated/0/Download/nomo_rejoin/`;
- installs the GitHub updater;
- keeps `gag` as a compatibility alias;
- stores only the public repository name in `updater.json`;
- does not save a GitHub token.

Then verify:

```bash
nomo version
```

Expected result:

```text
Local: V4.04
Remote: V4.04
Repo: YOUR_GITHUB_NAME/nomo-rejoin-releases
```

---

## Commands

```bash
nomo
```

Runs the local NOMO Rejoin file. It does not check GitHub.

```bash
nomo update
```

Checks the latest GitHub Release, downloads the ZIP, verifies SHA-256, compiles the Python file, backs up the current local build, and installs atomically.

```bash
nomo version
```

Shows local and remote versions.

```bash
nomo rollback
```

Restores the latest local backup.

```bash
nomo repo
```

Shows the configured public repository.

```bash
nomo configure-update OWNER/REPO
```

Changes the release repository.

```bash
gag
```

Compatibility alias for `nomo`.

---

## Optional automated publishing

Browser publishing requires no token. Automated publishing requires a **fine-grained personal access token** restricted to this one repository with:

```text
Repository access: Only select repositories
Selected repository: nomo-rejoin-releases
Repository permission: Contents — Read and write
```

The token is requested invisibly for the publish command and is not saved to disk.

Install publisher tools and publish V4.04:

```bash
bash /sdcard/Download/NOMO_GITHUB_SETUP/setup_and_publish.sh 'YOUR_GITHUB_NAME/nomo-rejoin-releases'
```

Or publish a future clean release ZIP:

```bash
nomo publish /sdcard/Download/NOMO_REJOIN_V4.05.zip V4.05 --change 'First change' --change 'Second change'
```

The publisher validates the ZIP before upload and refuses files whose names look like cookies, secrets, tokens, configs, runtime data, or logs. It creates a draft release, uploads the ZIP and SHA-256 file, then publishes the completed release.

## Future release ZIP format

The ZIP must contain exactly one:

```text
nomo_rejoin.py
```

It may contain one:

```text
nomo_pet_counter.lua
```

The `__version__` inside `nomo_rejoin.py` must match the release tag. Example:

```text
__version__ = "V4.05"
Tag: V4.05
Asset: NOMO_REJOIN_V4.05.zip
Checksum: NOMO_REJOIN_V4.05.sha256
```

## Public repository warning

Anyone can download assets from a public repository. This is necessary so every Redfinger can update without keeping a GitHub token. Keep all private/local data outside release ZIPs.
