# NOMO Rejoin Releases

Public release storage for NOMO Rejoin.

Each published release contains only clean program files:

- `nomo_rejoin.py`
- `nomo_pet_counter.lua`
- `release.json`
- `README_RELEASE.txt`

Local configuration, cookies, runtime state, logs, private-server credentials, API secrets, and tokens are never included.

Clients update manually with:

```bash
nomo update
```
