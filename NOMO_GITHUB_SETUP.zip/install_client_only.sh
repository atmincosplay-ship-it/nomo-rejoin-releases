#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
REPO="${1:-}"
if [ -z "$REPO" ]; then printf 'Public GitHub repository (OWNER/REPO): '; read -r REPO; fi
bash "$ROOT/install_current_release.sh"
bash "$ROOT/termux/install_nomo_github.sh" "$REPO"
echo
echo 'Client setup complete.'
echo 'After the first GitHub release is published, run: nomo version'
echo 'Future updates: nomo update'
