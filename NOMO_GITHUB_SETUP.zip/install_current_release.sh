#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
OLD="/storage/emulated/0/Download/gag_lite_rejoiner"
NEW="/storage/emulated/0/Download/nomo_rejoin"
MAIN_SRC="$ROOT/release/nomo_rejoin.py"
COUNTER_SRC="$ROOT/release/nomo_pet_counter.lua"
STAMP="$(date +%Y%m%d_%H%M%S)"

[ -f "$MAIN_SRC" ] || { echo "Missing $MAIN_SRC"; exit 1; }
[ -f "$COUNTER_SRC" ] || { echo "Missing $COUNTER_SRC"; exit 1; }
command -v python >/dev/null 2>&1 || { echo 'ERROR: Python is not installed in Termux.' >&2; exit 1; }
python -m py_compile "$MAIN_SRC"
mkdir -p "$NEW" "$NEW/backups"

if [ -f "$NEW/nomo_rejoin.py" ]; then
  B="$NEW/backups/${STAMP}_before_github_setup"
  mkdir -p "$B"
  cp -f "$NEW/nomo_rejoin.py" "$B/nomo_rejoin.py"
  [ -f "$NEW/nomo_pet_counter.lua" ] && cp -f "$NEW/nomo_pet_counter.lua" "$B/nomo_pet_counter.lua"
elif [ -f "$OLD/gag_lite_rejoiner.py" ]; then
  B="$NEW/backups/${STAMP}_before_rename"
  mkdir -p "$B"
  cp -f "$OLD/gag_lite_rejoiner.py" "$B/nomo_rejoin.py"
fi

for name in nomo.json config.json global_config_template.json runtime.json \
  hatcher_reporter_config.json hatcher_reporter_runtime.json cookie_cache.json \
  captcha_hold.json activity.log cookie_export.txt cookie_auth.txt cookies_only.txt; do
  if [ -f "$OLD/$name" ] && [ ! -e "$NEW/$name" ]; then
    cp -p "$OLD/$name" "$NEW/$name"
  fi
done

cp -f "$MAIN_SRC" "$NEW/nomo_rejoin.py"
cp -f "$COUNTER_SRC" "$NEW/nomo_pet_counter.lua"
rm -rf "$NEW/__pycache__"
python -m py_compile "$NEW/nomo_rejoin.py"
echo "Installed NOMO Rejoin V4.04 at $NEW"
