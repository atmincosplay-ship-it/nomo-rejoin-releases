#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
REPO="${1:-}"
if [ -z "$REPO" ]; then printf 'Public GitHub repository (OWNER/REPO): '; read -r REPO; fi
bash "$ROOT/install_current_release.sh"
bash "$ROOT/termux/install_nomo_github.sh" "$REPO"
mkdir -p /storage/emulated/0/Download/nomo_rejoin/releases
cp -f "$ROOT/UPLOAD_THESE_TO_GITHUB/NOMO_REJOIN_V4.04.zip" /storage/emulated/0/Download/nomo_rejoin/releases/
cp -f "$ROOT/UPLOAD_THESE_TO_GITHUB/NOMO_REJOIN_V4.04.sha256" /storage/emulated/0/Download/nomo_rejoin/releases/
echo
echo 'Publisher tools installed.'
echo 'Browser upload files copied to:'
echo '  /storage/emulated/0/Download/nomo_rejoin/releases/NOMO_REJOIN_V4.04.zip'
echo '  /storage/emulated/0/Download/nomo_rejoin/releases/NOMO_REJOIN_V4.04.sha256'
echo 'Automated publish command:'
echo "  nomo publish /storage/emulated/0/Download/nomo_rejoin/releases/NOMO_REJOIN_V4.04.zip V4.04 --change 'GitHub Releases migration'"
