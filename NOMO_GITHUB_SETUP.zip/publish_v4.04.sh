#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
REPO="${1:-}"
ARGS=()
if [ -n "$REPO" ]; then ARGS+=(--repo "$REPO"); fi
python "$ROOT/termux/nomo_github_publish.py" \
  "$ROOT/UPLOAD_THESE_TO_GITHUB/NOMO_REJOIN_V4.04.zip" \
  V4.04 \
  "${ARGS[@]}" \
  --change 'Renamed the project to NOMO Rejoin.' \
  --change 'Moved the canonical install to /storage/emulated/0/Download/nomo_rejoin/.' \
  --change 'Renamed the main file to nomo_rejoin.py and counter to nomo_pet_counter.lua.' \
  --change 'Added manual GitHub Releases updates with SHA-256 validation and rollback.' \
  --change 'Kept gag as a compatibility alias for nomo.'
