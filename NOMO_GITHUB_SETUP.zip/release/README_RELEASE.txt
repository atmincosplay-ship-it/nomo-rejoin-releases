NOMO Rejoin V4.04

Public release contents:
- nomo_rejoin.py
- nomo_pet_counter.lua
- release.json
- README_RELEASE.txt

Install path:
/storage/emulated/0/Download/nomo_rejoin/

Commands after the GitHub updater is installed:
- nomo
- nomo update
- nomo version
- nomo rollback
- gag

This release intentionally contains no nomo.json, cookies, runtime data,
private-server credentials, logs, GitHub tokens, or Cloudflare secrets.
