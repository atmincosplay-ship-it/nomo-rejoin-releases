#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
REPO="${1:-}"
if [ -z "$REPO" ]; then printf 'Public GitHub repository (OWNER/REPO): '; read -r REPO; fi
bash "$ROOT/install_publisher.sh" "$REPO"
echo
printf 'Publish V4.04 automatically now? [Y/n]: '
read -r ANSWER
case "${ANSWER:-Y}" in
  n|N|no|NO) echo 'Skipped. Use the browser method in README_SETUP.md.' ;;
  *) bash "$ROOT/publish_v4.04.sh" "$REPO" ;;
esac
