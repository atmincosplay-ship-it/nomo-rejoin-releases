#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

BASE="/storage/emulated/0/Download/nomo_rejoin"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
REPO="${1:-}"

if [ -z "$REPO" ]; then
  printf 'Public GitHub repository (OWNER/REPO): '
  read -r REPO
fi
[ -n "$REPO" ] || { echo 'ERROR: repository is required.' >&2; exit 1; }

command -v python >/dev/null 2>&1 || { echo 'ERROR: Python is not installed in Termux.' >&2; exit 1; }
mkdir -p "$BASE" "$BASE/backups" "$PREFIX/bin"

cp -f "$SCRIPT_DIR/nomo_github_updater.py" "$BASE/nomo_github_updater.py"
cp -f "$SCRIPT_DIR/nomo_github_publish.py" "$BASE/nomo_github_publish.py"
chmod 700 "$BASE/nomo_github_updater.py" "$BASE/nomo_github_publish.py"
python -m py_compile "$BASE/nomo_github_updater.py" "$BASE/nomo_github_publish.py"

[ -f "$PREFIX/bin/nomo" ] && cp -f "$PREFIX/bin/nomo" "$PREFIX/bin/nomo.before-github" || true
[ -f "$PREFIX/bin/gag" ] && cp -f "$PREFIX/bin/gag" "$PREFIX/bin/gag.before-github" || true

cat > "$PREFIX/bin/nomo" <<'EOF'
#!/data/data/com.termux/files/usr/bin/bash
set -e
BASE="/storage/emulated/0/Download/nomo_rejoin"
case "${1:-}" in
  update)
    shift; exec python "$BASE/nomo_github_updater.py" update "$@" ;;
  rollback)
    shift; exec python "$BASE/nomo_github_updater.py" rollback "$@" ;;
  version)
    shift; exec python "$BASE/nomo_github_updater.py" version "$@" ;;
  repo)
    shift; exec python "$BASE/nomo_github_updater.py" repo "$@" ;;
  configure-update)
    shift; exec python "$BASE/nomo_github_updater.py" configure "$@" ;;
  publish)
    shift; exec python "$BASE/nomo_github_publish.py" "$@" ;;
  '')
    exec python "$BASE/nomo_rejoin.py" ;;
  *)
    exec python "$BASE/nomo_rejoin.py" "$@" ;;
esac
EOF

cat > "$PREFIX/bin/gag" <<'EOF'
#!/data/data/com.termux/files/usr/bin/bash
exec nomo "$@"
EOF

chmod +x "$PREFIX/bin/nomo" "$PREFIX/bin/gag"
rm -f "$PREFIX/bin/gag-update"
python "$BASE/nomo_github_updater.py" configure "$REPO"
hash -r 2>/dev/null || true

echo
echo 'NOMO GitHub Releases updater installed.'
echo '  nomo           Run local NOMO; no update check'
echo '  nomo update    Manually install latest GitHub release'
echo '  nomo version   Show local and remote version'
echo '  nomo rollback  Restore latest local backup'
echo '  nomo repo      Show configured repository'
echo '  nomo publish   Publish a release with a GitHub token'
echo '  gag            Compatibility alias'
