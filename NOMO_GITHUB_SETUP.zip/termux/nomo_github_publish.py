#!/usr/bin/env python3
from __future__ import annotations

import argparse
import getpass
import hashlib
import json
import mimetypes
import os
import py_compile
import re
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

BASE_DIR = Path(os.environ.get("NOMO_BASE_DIR", "/storage/emulated/0/Download/nomo_rejoin"))
CONFIG_FILE = BASE_DIR / "updater.json"
DEFAULT_API_BASE = os.environ.get("NOMO_GITHUB_API_BASE", "https://api.github.com").rstrip("/")
API_VERSION = "2026-03-10"
MAX_BYTES = 25 * 1024 * 1024
VERSION_RE = re.compile(r'^__version__\s*=\s*["\'](V\d+\.\d+)["\']', re.M)
REPO_RE = re.compile(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")
BANNED_BASENAMES = {
    "nomo.json", "config.json", "runtime.json", "cookie_cache.json", "captcha_hold.json",
    "cookie_export.txt", "cookie_auth.txt", "cookies_only.txt", "updater.json",
}
BANNED_WORDS = ("secret", "token", "cookie", "credential", "activity.log")


class PublishError(RuntimeError):
    pass


def normalize_repo(value: str) -> str:
    value = str(value or "").strip().strip("/")
    if value.startswith("https://github.com/"):
        value = value[len("https://github.com/"):].strip("/")
    if value.endswith(".git"):
        value = value[:-4]
    if not REPO_RE.fullmatch(value):
        raise PublishError("Repository must look like OWNER/REPO.")
    return value


def configured_repo() -> str:
    if not CONFIG_FILE.exists():
        return ""
    try:
        data = json.loads(CONFIG_FILE.read_text())
        return str(data.get("repo") or "")
    except Exception:
        return ""


def canonical_version(value: str) -> str:
    match = re.fullmatch(r"[Vv](\d+)\.(\d+)", str(value or "").strip())
    if not match:
        raise PublishError("Version must look like V4.05.")
    return f"V{int(match.group(1))}.{int(match.group(2)):02d}"


def api_headers(token: str, content_type: str = "application/vnd.github+json") -> dict[str, str]:
    return {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {token}",
        "X-GitHub-Api-Version": API_VERSION,
        "User-Agent": "NOMO-Rejoin-GitHub-Publisher/1.0",
        "Content-Type": content_type,
    }


def request_json(url: str, method: str, token: str, payload: dict | None = None,
                 allowed: tuple[int, ...] = (200, 201)) -> tuple[int, dict]:
    body = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=body, method=method, headers=api_headers(token))
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            status = getattr(resp, "status", 200)
            raw = resp.read()
    except urllib.error.HTTPError as exc:
        raw = exc.read()
        status = exc.code
    except urllib.error.URLError as exc:
        raise PublishError(f"Network error: {exc.reason}") from exc

    try:
        data = json.loads(raw.decode("utf-8")) if raw else {}
    except Exception:
        data = {"raw": raw.decode("utf-8", errors="replace")[:1000]}
    if status not in allowed:
        message = data.get("message") if isinstance(data, dict) else str(data)
        raise PublishError(f"GitHub HTTP {status}: {message}")
    return status, data if isinstance(data, dict) else {}


def upload_asset(upload_url: str, token: str, path: Path, content_type: str) -> dict:
    base = upload_url.split("{", 1)[0]
    url = f"{base}?name={urllib.parse.quote(path.name)}"
    raw = path.read_bytes()
    req = urllib.request.Request(
        url,
        data=raw,
        method="POST",
        headers=api_headers(token, content_type),
    )
    try:
        with urllib.request.urlopen(req, timeout=180) as resp:
            status = getattr(resp, "status", 201)
            body = resp.read()
    except urllib.error.HTTPError as exc:
        body = exc.read()
        status = exc.code
    except urllib.error.URLError as exc:
        raise PublishError(f"Asset upload network error: {exc.reason}") from exc

    try:
        data = json.loads(body.decode("utf-8")) if body else {}
    except Exception:
        data = {"raw": body.decode("utf-8", errors="replace")[:1000]}
    if status != 201:
        raise PublishError(f"Asset upload failed HTTP {status}: {data.get('message') or data}")
    return data


def validate_release_zip(zip_path: Path, version: str) -> None:
    if not zip_path.is_file():
        raise PublishError(f"ZIP not found: {zip_path}")
    if zip_path.stat().st_size > MAX_BYTES:
        raise PublishError("ZIP exceeds the 25 MiB NOMO safety limit.")
    try:
        with zipfile.ZipFile(zip_path) as zf:
            names = zf.namelist()
            total = 0
            for info in zf.infolist():
                p = Path(info.filename)
                if p.is_absolute() or ".." in p.parts:
                    raise PublishError(f"Unsafe ZIP member: {info.filename}")
                total += int(info.file_size)
                if total > 40 * 1024 * 1024:
                    raise PublishError("Uncompressed ZIP is unexpectedly large.")
                base = p.name.lower()
                if base in BANNED_BASENAMES or any(word in base for word in BANNED_WORDS):
                    raise PublishError(f"Public release ZIP contains a forbidden local/private file: {info.filename}")

            py_names = [n for n in names if Path(n).name == "nomo_rejoin.py"]
            if len(py_names) != 1:
                raise PublishError("ZIP must contain exactly one nomo_rejoin.py.")
            counter_names = [n for n in names if Path(n).name == "nomo_pet_counter.lua"]
            if len(counter_names) > 1:
                raise PublishError("ZIP contains multiple nomo_pet_counter.lua files.")

            with tempfile.TemporaryDirectory(prefix="nomo-publish-") as tmpdir:
                candidate = Path(tmpdir) / "nomo_rejoin.py"
                with zf.open(py_names[0]) as src, candidate.open("wb") as dst:
                    dst.write(src.read())
                text = candidate.read_text(errors="strict")
                match = VERSION_RE.search(text)
                if not match:
                    raise PublishError("nomo_rejoin.py has no __version__ marker.")
                actual = canonical_version(match.group(1))
                if actual != version:
                    raise PublishError(f"Version mismatch: requested={version}, file={actual}")
                if "NOMO REJOIN" not in text[:8000].upper():
                    raise PublishError("nomo_rejoin.py does not look like NOMO Rejoin.")
                py_compile.compile(str(candidate), doraise=True)
    except zipfile.BadZipFile as exc:
        raise PublishError("Release file is not a valid ZIP.") from exc


def release_notes(version: str, changes: list[str]) -> str:
    lines = [f"# NOMO Rejoin {version}", "", "## Changes"]
    if changes:
        lines.extend(f"- {item}" for item in changes)
    else:
        lines.append("- NOMO Rejoin release.")
    lines += [
        "",
        "## Install",
        "Run `nomo update` on configured clients.",
        "",
        "The ZIP intentionally contains program files only—no cookies, configs, logs, or secrets.",
    ]
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Publish a NOMO Rejoin release to GitHub Releases")
    parser.add_argument("zip_file")
    parser.add_argument("version")
    parser.add_argument("--repo", default="")
    parser.add_argument("--token", default="")
    parser.add_argument("--change", action="append", default=[])
    parser.add_argument("--prerelease", action="store_true")
    args = parser.parse_args()

    draft_release_id = None
    try:
        version = canonical_version(args.version)
        repo = normalize_repo(args.repo or configured_repo())
        zip_path = Path(args.zip_file).expanduser().resolve()
        validate_release_zip(zip_path, version)

        token = args.token or os.environ.get("GITHUB_TOKEN", "")
        if not token:
            token = getpass.getpass("GitHub fine-grained token: ")
        if not token:
            raise PublishError("A GitHub token is required for automated publishing.")

        _, repo_info = request_json(f"{DEFAULT_API_BASE}/repos/{repo}", "GET", token)
        if repo_info.get("private"):
            print("WARNING: repository is private; unauthenticated client updates will not work.", file=sys.stderr)
        default_branch = str(repo_info.get("default_branch") or "main")

        try:
            request_json(
                f"{DEFAULT_API_BASE}/repos/{repo}/releases/tags/{urllib.parse.quote(version)}",
                "GET", token,
            )
            raise PublishError(f"Release {version} already exists. Use a new version instead of replacing it.")
        except PublishError as exc:
            if "HTTP 404" not in str(exc):
                raise

        body = release_notes(version, args.change)
        print(f"Creating draft release {version} in {repo}...")
        _, release = request_json(
            f"{DEFAULT_API_BASE}/repos/{repo}/releases",
            "POST",
            token,
            {
                "tag_name": version,
                "target_commitish": default_branch,
                "name": f"NOMO Rejoin {version}",
                "body": body,
                "draft": True,
                "prerelease": bool(args.prerelease),
            },
            allowed=(201,),
        )
        draft_release_id = int(release.get("id"))
        upload_url = str(release.get("upload_url") or "")
        if not upload_url:
            raise PublishError("GitHub did not return an upload URL.")

        sha = hashlib.sha256(zip_path.read_bytes()).hexdigest()
        sha_path = zip_path.with_name(f"NOMO_REJOIN_{version}.sha256")
        sha_path.write_text(f"{sha}  {zip_path.name}\n")

        print(f"Uploading {zip_path.name}...")
        upload_asset(upload_url, token, zip_path, "application/zip")
        print(f"Uploading {sha_path.name}...")
        upload_asset(upload_url, token, sha_path, "text/plain")

        print("Publishing release...")
        _, published = request_json(
            f"{DEFAULT_API_BASE}/repos/{repo}/releases/{draft_release_id}",
            "PATCH",
            token,
            {"draft": False, "make_latest": "true" if not args.prerelease else "legacy"},
        )
        print(f"Published {version}")
        print(f"SHA-256: {sha}")
        print(f"Release: {published.get('html_url') or f'https://github.com/{repo}/releases/tag/{version}'}")
        print("Token was used only for this command and was not saved.")
        return 0
    except PublishError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        if draft_release_id:
            print("A draft release may remain on GitHub. Open Releases and either finish or delete the draft.", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nCancelled.", file=sys.stderr)
        if draft_release_id:
            print("A draft release may remain on GitHub.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
