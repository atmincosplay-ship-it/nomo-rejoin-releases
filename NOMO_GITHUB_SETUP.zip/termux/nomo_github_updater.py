#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import py_compile
import re
import shutil
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

BASE_DIR = Path(os.environ.get("NOMO_BASE_DIR", "/storage/emulated/0/Download/nomo_rejoin"))
APP_FILE = BASE_DIR / "nomo_rejoin.py"
COUNTER_FILE = BASE_DIR / "nomo_pet_counter.lua"
CONFIG_FILE = BASE_DIR / "updater.json"
BACKUP_DIR = BASE_DIR / "backups"
DEFAULT_API_BASE = os.environ.get("NOMO_GITHUB_API_BASE", "https://api.github.com").rstrip("/")
API_VERSION = "2026-03-10"
DEFAULT_TIMEOUT = 60
MAX_RELEASE_BYTES = 25 * 1024 * 1024
MAX_METADATA_BYTES = 1024 * 1024
VERSION_RE = re.compile(r'^__version__\s*=\s*["\'](V\d+\.\d+)["\']', re.M)
REPO_RE = re.compile(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")


class UpdateError(RuntimeError):
    pass


def load_config() -> dict:
    if not CONFIG_FILE.exists():
        return {}
    try:
        data = json.loads(CONFIG_FILE.read_text())
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_config(data: dict) -> None:
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    tmp = CONFIG_FILE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, indent=2))
    os.replace(tmp, CONFIG_FILE)


def normalize_repo(value: str) -> str:
    value = str(value or "").strip().strip("/")
    if value.startswith("https://github.com/"):
        value = value[len("https://github.com/"):].strip("/")
    if value.endswith(".git"):
        value = value[:-4]
    if not REPO_RE.fullmatch(value):
        raise UpdateError("Repository must look like OWNER/REPO.")
    return value


def canonical_version(value: str) -> str:
    match = re.fullmatch(r"[Vv](\d+)\.(\d+)", str(value or "").strip())
    if not match:
        raise UpdateError(f"Invalid release tag/version: {value!r}")
    return f"V{int(match.group(1))}.{int(match.group(2)):02d}"


def version_tuple(value: str) -> tuple[int, int]:
    try:
        normalized = canonical_version(value)
    except UpdateError:
        return (-1, -1)
    match = re.fullmatch(r"V(\d+)\.(\d+)", normalized)
    return int(match.group(1)), int(match.group(2))


def github_headers(binary: bool = False) -> dict[str, str]:
    return {
        "Accept": "application/octet-stream" if binary else "application/vnd.github+json",
        "User-Agent": "NOMO-Rejoin-GitHub-Updater/1.0",
        "X-GitHub-Api-Version": API_VERSION,
        "Cache-Control": "no-cache",
    }


def http_get_bytes(url: str, max_bytes: int, headers: dict[str, str] | None = None,
                   timeout: int = DEFAULT_TIMEOUT) -> bytes:
    merged = github_headers()
    if headers:
        merged.update(headers)
    req = urllib.request.Request(url, headers=merged)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            status = getattr(resp, "status", 200)
            if status != 200:
                raise UpdateError(f"HTTP {status}: {url}")
            length = int(resp.headers.get("Content-Length") or 0)
            if length and length > max_bytes:
                raise UpdateError(f"Download too large: {length} bytes")
            out = bytearray()
            while True:
                chunk = resp.read(128 * 1024)
                if not chunk:
                    break
                out.extend(chunk)
                if len(out) > max_bytes:
                    raise UpdateError(f"Download exceeded {max_bytes} bytes")
            return bytes(out)
    except urllib.error.HTTPError as exc:
        detail = ""
        try:
            detail = exc.read().decode("utf-8", errors="replace")[:500]
        except Exception:
            pass
        if exc.code == 404:
            raise UpdateError(f"GitHub returned 404. Check the repository and make sure a published release exists.\n{detail}") from exc
        if exc.code == 403:
            raise UpdateError(f"GitHub returned 403. The API may be rate-limited or the repository may not be public.\n{detail}") from exc
        raise UpdateError(f"GitHub HTTP {exc.code}: {detail or url}") from exc
    except urllib.error.URLError as exc:
        raise UpdateError(f"Network error: {exc.reason}") from exc


def http_get_json(url: str) -> dict:
    raw = http_get_bytes(url, MAX_METADATA_BYTES)
    try:
        data = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise UpdateError("GitHub returned invalid JSON.") from exc
    if not isinstance(data, dict):
        raise UpdateError("GitHub response was not a JSON object.")
    return data


def configured_repo() -> str:
    cfg = load_config()
    return normalize_repo(str(cfg.get("repo") or ""))


def get_latest_release(repo: str) -> dict:
    repo = normalize_repo(repo)
    return http_get_json(f"{DEFAULT_API_BASE}/repos/{repo}/releases/latest?t={int(time.time())}")


def select_release_assets(release: dict) -> tuple[str, dict, dict | None, str | None]:
    version = canonical_version(str(release.get("tag_name") or ""))
    assets = release.get("assets")
    if not isinstance(assets, list):
        raise UpdateError("Latest GitHub release has no assets list.")

    preferred_zip = f"NOMO_REJOIN_{version}.zip"
    zip_asset = next((a for a in assets if isinstance(a, dict) and a.get("name") == preferred_zip), None)
    if zip_asset is None:
        candidates = [
            a for a in assets
            if isinstance(a, dict)
            and str(a.get("name") or "").upper().startswith("NOMO_REJOIN_")
            and str(a.get("name") or "").lower().endswith(".zip")
        ]
        if len(candidates) != 1:
            raise UpdateError(
                f"Release must contain exactly one NOMO_REJOIN_*.zip asset; expected {preferred_zip}."
            )
        zip_asset = candidates[0]

    zip_name = str(zip_asset.get("name") or "")
    zip_url = str(zip_asset.get("browser_download_url") or "")
    if not zip_url.startswith("https://") and not DEFAULT_API_BASE.startswith("http://127.0.0.1"):
        raise UpdateError("Release ZIP has an unsafe download URL.")

    sha_names = {
        f"{zip_name}.sha256",
        f"{Path(zip_name).stem}.sha256",
        f"NOMO_REJOIN_{version}.sha256",
    }
    sha_asset = next(
        (a for a in assets if isinstance(a, dict) and str(a.get("name") or "") in sha_names),
        None,
    )

    digest = str(zip_asset.get("digest") or "")
    digest_sha = None
    if digest.lower().startswith("sha256:"):
        candidate = digest.split(":", 1)[1].strip().lower()
        if re.fullmatch(r"[a-f0-9]{64}", candidate):
            digest_sha = candidate

    if sha_asset is None and digest_sha is None:
        raise UpdateError(
            "Release is missing its SHA-256 asset. Upload NOMO_REJOIN_<VERSION>.sha256 too."
        )
    return version, zip_asset, sha_asset, digest_sha


def get_expected_sha(zip_name: str, sha_asset: dict | None, digest_sha: str | None) -> str:
    if sha_asset is not None:
        url = str(sha_asset.get("browser_download_url") or "")
        raw = http_get_bytes(url, 64 * 1024)
        text = raw.decode("utf-8", errors="replace")
        match = re.search(r"\b([a-fA-F0-9]{64})\b", text)
        if not match:
            raise UpdateError(f"Invalid SHA-256 file for {zip_name}.")
        file_sha = match.group(1).lower()
        if digest_sha and digest_sha != file_sha:
            raise UpdateError("GitHub asset digest and uploaded .sha256 file disagree.")
        return file_sha
    if digest_sha:
        return digest_sha
    raise UpdateError("No usable SHA-256 was found.")


def read_local_version(path: Path | None = None) -> str:
    path = path or APP_FILE
    try:
        text = path.read_text(errors="replace")
    except Exception:
        return "MISSING"
    match = VERSION_RE.search(text)
    return match.group(1) if match else "UNKNOWN"


def ensure_valid_python(path: Path, expected_version: str) -> None:
    text = path.read_text(errors="strict")
    match = VERSION_RE.search(text)
    if not match:
        raise UpdateError("Downloaded Python has no __version__ marker.")
    actual = canonical_version(match.group(1))
    if actual != expected_version:
        raise UpdateError(f"Version mismatch: release={expected_version}, file={actual}")
    if "NOMO REJOIN" not in text[:8000].upper():
        raise UpdateError("Downloaded Python does not look like NOMO Rejoin.")
    py_compile.compile(str(path), doraise=True)


def validate_zip_members(zf: zipfile.ZipFile) -> None:
    total = 0
    for info in zf.infolist():
        name = info.filename
        p = Path(name)
        if p.is_absolute() or ".." in p.parts:
            raise UpdateError(f"Unsafe ZIP member: {name}")
        total += int(info.file_size)
        if total > 40 * 1024 * 1024:
            raise UpdateError("Uncompressed release contents are unexpectedly large.")


def extract_named(zf: zipfile.ZipFile, basename: str, destination: Path, max_size: int) -> bool:
    candidates = [name for name in zf.namelist() if Path(name).name == basename]
    if not candidates:
        return False
    if len(candidates) != 1:
        raise UpdateError(f"ZIP must contain exactly one {basename}.")
    info = zf.getinfo(candidates[0])
    if info.file_size > max_size:
        raise UpdateError(f"{basename} is unexpectedly large.")
    with zf.open(info) as src, destination.open("wb") as dst:
        shutil.copyfileobj(src, dst)
    return True


def make_backup_bundle(label: str) -> Path | None:
    if not APP_FILE.exists() and not COUNTER_FILE.exists():
        return None
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    version = read_local_version().replace("/", "_")
    folder = BACKUP_DIR / f"{stamp}_{version}_{label}"
    suffix = 1
    while folder.exists():
        folder = BACKUP_DIR / f"{stamp}_{version}_{label}_{suffix}"
        suffix += 1
    folder.mkdir(parents=True)
    if APP_FILE.exists():
        shutil.copy2(APP_FILE, folder / APP_FILE.name)
    if COUNTER_FILE.exists():
        shutil.copy2(COUNTER_FILE, folder / COUNTER_FILE.name)
    bundles = sorted((p for p in BACKUP_DIR.iterdir() if p.is_dir()), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in bundles[8:]:
        shutil.rmtree(old, ignore_errors=True)
    return folder


def install_update(force: bool = False) -> int:
    repo = configured_repo()
    release = get_latest_release(repo)
    remote_version, zip_asset, sha_asset, digest_sha = select_release_assets(release)
    local_version = read_local_version()
    print(f"Repository: {repo}")
    print(f"Local     : {local_version}")
    print(f"Remote    : {remote_version}")

    if not force and local_version == remote_version:
        print("Already on the latest version.")
        return 0
    if not force and version_tuple(remote_version) < version_tuple(local_version):
        raise UpdateError("Remote version is older than the installed version. Use --force to install it.")

    zip_name = str(zip_asset.get("name") or "")
    zip_url = str(zip_asset.get("browser_download_url") or "")
    expected_sha = get_expected_sha(zip_name, sha_asset, digest_sha)
    print(f"Downloading {zip_name}...")
    raw = http_get_bytes(zip_url, MAX_RELEASE_BYTES)
    actual_sha = hashlib.sha256(raw).hexdigest()
    if actual_sha != expected_sha:
        raise UpdateError(f"SHA-256 mismatch\nexpected: {expected_sha}\nactual:   {actual_sha}")

    BASE_DIR.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="nomo-update-", dir=str(BASE_DIR)) as tmpdir:
        tmp = Path(tmpdir)
        zip_path = tmp / zip_name
        zip_path.write_bytes(raw)
        candidate = tmp / "nomo_rejoin.py"
        counter_candidate = tmp / "nomo_pet_counter.lua"
        try:
            with zipfile.ZipFile(zip_path) as zf:
                validate_zip_members(zf)
                if not extract_named(zf, "nomo_rejoin.py", candidate, 8 * 1024 * 1024):
                    raise UpdateError("Release ZIP does not contain nomo_rejoin.py.")
                counter_found = extract_named(zf, "nomo_pet_counter.lua", counter_candidate, 3 * 1024 * 1024)
        except zipfile.BadZipFile as exc:
            raise UpdateError("Downloaded release is not a valid ZIP.") from exc

        ensure_valid_python(candidate, remote_version)
        backup = make_backup_bundle("pre_github_update")
        staged = BASE_DIR / "nomo_rejoin.py.new"
        shutil.copy2(candidate, staged)
        os.replace(staged, APP_FILE)
        if counter_found:
            staged_counter = BASE_DIR / "nomo_pet_counter.lua.new"
            shutil.copy2(counter_candidate, staged_counter)
            os.replace(staged_counter, COUNTER_FILE)
        shutil.rmtree(BASE_DIR / "__pycache__", ignore_errors=True)

    print(f"Installed {remote_version} successfully.")
    if backup:
        print(f"Backup: {backup}")
    body = str(release.get("body") or "").strip()
    if body:
        print("Release notes:")
        for line in body.splitlines()[:12]:
            print(f"  {line}")
    print("Run: nomo")
    return 0


def rollback() -> int:
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    bundles = sorted((p for p in BACKUP_DIR.iterdir() if p.is_dir()), key=lambda p: p.stat().st_mtime, reverse=True)
    if not bundles:
        raise UpdateError("No local rollback backup exists.")
    source = bundles[0]
    source_app = source / APP_FILE.name
    if not source_app.exists():
        raise UpdateError(f"Backup is missing {APP_FILE.name}: {source}")
    expected = read_local_version(source_app)
    ensure_valid_python(source_app, canonical_version(expected))
    current_backup = make_backup_bundle("pre_rollback")
    staged = BASE_DIR / "nomo_rejoin.py.rollback"
    shutil.copy2(source_app, staged)
    os.replace(staged, APP_FILE)
    source_counter = source / COUNTER_FILE.name
    if source_counter.exists():
        staged_counter = BASE_DIR / "nomo_pet_counter.lua.rollback"
        shutil.copy2(source_counter, staged_counter)
        os.replace(staged_counter, COUNTER_FILE)
    shutil.rmtree(BASE_DIR / "__pycache__", ignore_errors=True)
    print(f"Rolled back to {expected}.")
    print(f"Restored: {source}")
    if current_backup:
        print(f"Previous current build backed up: {current_backup}")
    return 0


def show_version() -> int:
    print(f"Local: {read_local_version()}")
    cfg = load_config()
    repo = str(cfg.get("repo") or "")
    if not repo:
        print("Remote: not configured")
        return 0
    try:
        repo = normalize_repo(repo)
        release = get_latest_release(repo)
        remote, _, _, _ = select_release_assets(release)
        print(f"Remote: {remote}")
        print(f"Repo: {repo}")
        html_url = str(release.get("html_url") or "")
        if html_url:
            print(f"Release: {html_url}")
    except Exception as exc:
        print(f"Remote: unavailable ({exc})")
        print(f"Repo: {repo}")
    return 0


def configure(repo: str, skip_check: bool = False) -> int:
    repo = normalize_repo(repo)
    if not skip_check:
        try:
            info = http_get_json(f"{DEFAULT_API_BASE}/repos/{repo}")
            if info.get("private"):
                raise UpdateError("The repository is private. Public clients cannot update without a token.")
        except UpdateError as exc:
            if "404" in str(exc):
                raise UpdateError("Repository not found. Create it first and make it public.") from exc
            raise
    cfg = load_config()
    cfg.update({
        "provider": "github",
        "repo": repo,
        "configured_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
    })
    cfg.pop("base_url", None)
    save_config(cfg)
    print(f"GitHub updater configured: {repo}")
    return 0


def show_repo() -> int:
    cfg = load_config()
    repo = str(cfg.get("repo") or "")
    if not repo:
        print("GitHub repository is not configured.")
        return 1
    repo = normalize_repo(repo)
    print(f"Repository: {repo}")
    print(f"Page: https://github.com/{repo}")
    print(f"Releases: https://github.com/{repo}/releases")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="NOMO Rejoin manual GitHub Releases updater")
    sub = parser.add_subparsers(dest="command", required=True)
    update = sub.add_parser("update")
    update.add_argument("--force", action="store_true")
    sub.add_parser("rollback")
    sub.add_parser("version")
    sub.add_parser("repo")
    config = sub.add_parser("configure")
    config.add_argument("repo")
    config.add_argument("--skip-check", action="store_true")
    args = parser.parse_args()
    try:
        if args.command == "update":
            return install_update(force=args.force)
        if args.command == "rollback":
            return rollback()
        if args.command == "version":
            return show_version()
        if args.command == "repo":
            return show_repo()
        if args.command == "configure":
            return configure(args.repo, skip_check=args.skip_check)
    except UpdateError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nCancelled.", file=sys.stderr)
        return 130
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
